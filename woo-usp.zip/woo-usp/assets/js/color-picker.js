(function ($) {
  $(function () {
    $('.my-input-class').wpColorPicker();
  });
}(jQuery));


